# Introduction

[Stockfish](https://stockfishchess.org/) is a **free, open source, and strong UCI chess engine** derived from Glaurung 2.1 that analyzes chess positions and computes the optimal moves.

Stockfish **does not include a graphical user interface** (GUI), which is needed to display a chessboard and to make it easy to input moves. Several [free GUIs](Download-and-usage#free) have been developed independently of Stockfish and are available online.
**Read the documentation for the GUI** of your choice to find out how to use it with Stockfish.

## Guides

* For users
  * [Download Stockfish](Download-and-usage#download-stockfish)
  * [Download GUI](Download-and-usage#download-a-chess-gui)
  * [Install in GUI](Download-and-usage#install-in-a-chess-gui)
  * [Commands and options](UCI-Protocol-and-Stockfish-Commands)
  * [Frequently asked questions (FAQ)](Stockfish-FAQ)

* [For Developers](Developers)
  * [Compiling from sources](Compiling-from-source)
  * [Using Stockfish in your project](Developers#using-stockfish-in-your-own-project)
  * [Contributing](Developers#participating-in-the-project)
  * [Copying](https://github.com/official-stockfish/Stockfish/blob/master/Copying.txt)

## Support

If you're looking for any kind of assistance with Stockfish.

* [Discord](https://discord.gg/GWDRS3kU6R)
* [Github discussions](https://github.com/official-stockfish/Stockfish/discussions/categories/q-a)

## Related repositories

* Trainer: [official-stockfish/nnue-pytorch](https://github.com/official-stockfish/nnue-pytorch)
* Fishtest: [official-stockfish/fishtest](https://github.com/official-stockfish/fishtest)
* Website: [official-stockfish/stockfish-web](https://github.com/official-stockfish/stockfish-web)
* Docs website: [official-stockfish/docs](https://github.com/official-stockfish/docs)
* WDL model: [official-stockfish/WDL_model](https://github.com/official-stockfish/WDL_model)
* Fishtest worker setup: [ppigazzini/fishtest-worker-setup](https://github.com/ppigazzini/fishtest-worker-setup)
* Matetrack: [vondele/matetrack](https://github.com/vondele/matetrack)
* Nettest: [vondele/nettest](https://github.com/vondele/nettest)
* Mac app: [daylen/stockfish-mac](https://github.com/daylen/stockfish-mac)

See also our overview of [Governance and Responsibilities](Governance-and-responsibilities).
